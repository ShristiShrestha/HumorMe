package com.example.humorme

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HumormeApplicationTests {

	@Test
	fun contextLoads() {
	}

}
