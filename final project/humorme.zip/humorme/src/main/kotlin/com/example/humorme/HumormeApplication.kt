package com.example.humorme

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class HumormeApplication

fun main(args: Array<String>) {
	runApplication<HumormeApplication>(*args)
}
