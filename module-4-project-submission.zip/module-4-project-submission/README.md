Guide
---

- Checkout the project [here](http://3.85.85.196:8080/CSC7510Mod4/html/index.html)
- Java servelets are inside [java folder](/java)
- HTML pages are inside [web folder](/web)
- The screenshots are inside [screenshots folder](/screenshots)
- I have also added a .war file for testing (CSC7510Mod4.war)